#!/usr/bin/env python
# coding: utf-8

# In[3]:


import pandas as pd
import numpy as np 
import matplotlib.pyplot as plt
import seaborn as sns


# # * Data Wrangling

# #### Tip: In this section of the report, you will load in the data, check for cleanliness, and then trim and clean your dataset for analysis. Make sure that you document your steps carefully and justify your cleaning decisions.

# In[4]:


# load the Data Set 
df=pd.read_csv('KaggleV2-May-2016.csv')
# sample from data 
df.head()


# # * Introducation 

# ## Data Identification
# 
# ### PatientId :
# ###### The ID of patient
# ### AppointmentID :
# ###### The ID of appointment
# ### Gender
# ###### the gender of patient, Female or Male.
# ### ScheduledDay :
# ###### The day that the patient set up an appointement
# ### AppointmentDay :
# ###### The day of the appointment.
# ### Age :
# ###### The age of patient
# ### Neighbourhood :
# ###### Where the appointment takes place.
# ### Scholarship :
# ###### Whether or not the patient is enrolled in Brasilian welfare program Bolsa Família. Value : True/False
# ### Hipertension :
# ###### Whetther or not the patient have a hipertension. Values : True/False
# ### Diabetes :
# ###### Whetther or not the patient have a Diabetes. Values : True/False
# ### Alcoholism
# ###### Whetther or not the patient is a Alcoholism. Values : True/False
# ### Handcap
# ###### Whetther or not the patient is a Handcap. Values : True/False
# ### SMS_received :
# ###### Number of message sent to the patient.
# ### No-show :
# ###### ‘No’ if the patient showed up to their appointment, and ‘Yes’ if they did not show up.	 

#                  -----------------------------------------------------------------

# # * Question we could explore

# ##### Q1: Does the Gender effect the health careing??
# ##### Q2 how mush patient showed attending accoreding to Appointment??
# ##### Q3: what are major age got appoiment??
# ##### Q4: what are highly time for appoiment??
# ##### Q5: What is the effect of Neighbourhood ??
# ##### Q6: what is the effect of the SMS- receied on Appointment booking??
# ##### Q7: what is effect of the Age to missed the appoiment??
# ##### Q8: what is effect of the Gender to missed the appoiment?

#                         ------------------------------------------------------

# # * Check & Clean the Data Set

# In[5]:


# try to check all the data type before start working on it
df.info()


# ## incorrect data type  ScheduledDay & AppointmentDay

# In[6]:


# fix the data type
df.ScheduledDay=pd.to_datetime(df.ScheduledDay)
df.ScheduledDay.head(1)


# In[7]:


df.AppointmentDay=pd.to_datetime(df.AppointmentDay)
df.head(10)


# In[8]:


# confirmed the data type changed
df.info()


# ## correct the AppointmentDay & ScheduledDay to date time data

# In[9]:


df.shape


# In[10]:


#check missing data
df.isnull().sum()


# In[11]:


# check data duplication
df.duplicated().sum()


# ## No duplicated Data & NO missing Data 

# In[12]:


# over Viwe about the data describe
df.describe()


# In[ ]:


# the min value at Age column in negative (-1) this incorrected data and making the outlier on data analysis.


# In[13]:


df.Age.min()


# ## from the data discribtion found negative value on Age column & check if we have more

# In[14]:


# check how many negative value we have?
df.Age.value_counts()


# ## only one negative value ('-1') filter it from the data

# In[15]:


# drop this value from data set to keep data on good shape
df.drop(df.query("Age == -1").index,inplace=True)


# In[17]:


#check drop the negative value 
df['Age'].value_counts()


# In[18]:


#check the number of rows after drop the incorrected value
df.shape


# In[19]:


#check the sample from No-show colunm to understand it
df['No-show'].sample(5)


# In[20]:


# calculate the total patient take appointment
total_patient= df['AppointmentID'].count()
total_patient


# In[23]:


# how many female patient tack appointment?
total_femal_patient=df.query('Gender== "F"')['AppointmentID'].count()
total_femal_patient


# In[22]:


total_femal_patient=df.query('Gender== "F"')['AppointmentID'].count()
total_femal_patient


# In[24]:


# how many male patient tack appointment?
total_male_patient=total_patient- total_femal_patient
total_male_patient


# In[25]:


# remane No-show column to be easy to use
df.rename(columns={'No-show':'showed'}, inplace=True)
df.showed.head(1)


# In[26]:


# how any patient want to the appointment?
total_patient_showed=df.query('showed== "No"')['AppointmentID'].count()
total_patient_showed


# In[27]:


# how any patient didn't go to the appointment?
total_patient_noshowed=df.query('showed=="Yes"')['AppointmentID'].count()
total_patient_noshowed


# In[35]:


# describe the schedual & appointment 
df[["ScheduledDay","AppointmentDay"]].describe()


# In[36]:


# how may patient got appointment and has Hipertension?
precentage_Hipertension_patient= df.Hipertension.sum()/total_patient*100
precentage_Hipertension_patient


# In[37]:


# how may patient got appointment and has Diabetes?
precentage_Diabetes_patient=df.Diabetes.sum()/total_patient*100
precentage_Diabetes_patient


# In[38]:


# how may patient got appointment and has HAlcoholism?
precentage_Alcoholism_patient=df.Alcoholism.sum()/total_patient*100
precentage_Alcoholism_patient


# In[39]:


# how may patient got appointment and has handcap?
precentage_Handcap_patient=df.Handcap.sum()/total_patient*100
precentage_Handcap_patient


# In[72]:


# how many patient neigbourhood
number_of_Neighbourhood=df.Neighbourhood.nunique()
number_of_Neighbourhood


#                         ------------------------------------------------------

# # * (EDA) Exploratory Data Analysis

# In[40]:


#General visualization for data set
df.hist(figsize=(10,10));
plt.title('General review data set');


# ## From this over view can see
# ##### * the most of patient  appointment age between 0 to 60 years
# ##### *Only 19.7% Alcoholism from patient .
# ##### *Only  7% are 'Diabetes' , 3%  'Hipertension' & 2 %  Handcap.
# ##### * the most of them didn't have Scholarship.
# ##### * the most of them didn't receive the SMS.
# ##### * they have 81 nighbourhood.
# ##### * the  ScheduledDay start at 2015-11-10 and ended at 2016-06-08.

# # *Q1: Does the Gender effect the health careing??

# In[47]:


df.Gender.value_counts().plot(kind='pie',labels=['Female','Male'],figsize=(8,8));
plt.title('Precentage of male to femal Appointment');


# ## From the charts above, we can conclude that Female are the most patients who got medical appointment with 64.9 %.

# In[42]:


#calculate thr proportion of female
prop_female= total_femal_patient/ total_patient
prop_female


# In[43]:


#calculate thr proportion of male
prop_male= total_male_patient/ total_patient
prop_male


# In[46]:


plt.bar([1,2], [prop_female,prop_male], tick_label=['prop_female','prop_male']);
plt.title('female male prop correlation');
plt.xlabel('prop correlation');
plt.ylabel('prop correlation');


# ## From the Previous chart the proportion of female is approximately duplicate of male . 

# # * Q2 how mush patient showed attending accoreding to Appointment???

# In[48]:


plt.bar([1,2],[total_patient_showed, total_patient_noshowed], tick_label=['show','No-show']);
plt.title('show & No-show');
plt.xlabel('show/No-show');
plt.ylabel('Number of Appointment');


# ## From chart above can see almost of the patient attended the appointment

# # * Q3: what are major age got appoiment?

# In[33]:


df['Age'].hist(figsize=(10,5));
plt.title('AGE Attended');
plt.xlabel('Age');
plt.ylabel('Number of Attandace');


# ## the Majore Age attended btween 0 to 60 years

# # * Q4: what are highly time for appoiment?

# In[50]:


df.ScheduledDay.dt.date.value_counts().plot(kind='line',figsize=(10,5));
plt.title('Max sasone Appointment');
plt.xlabel('Months');
plt.ylabel('Number of appointment');


# ## From the chart above the highly activity months ('May & June')

# In[52]:


df.AppointmentDay.dt.date.value_counts().plot(kind='line', figsize=(10,5));
plt.title('Month Activity chart');
plt.xlabel('Activity during month of May');
plt.ylabel('Number of Appointment');


# ## From chart above will find the Max Appointment at the start and end of the month.
# ## the Min appointment at the middel of the month.
# 

# # * Q5: What is the effect of Neighbourhood ??

# In[53]:


df.Neighbourhood.value_counts().plot(kind='bar', figsize=(15,5));
plt.title('Neighbourhood Effect on Appointment');
plt.xlabel('Patient Area');
plt.ylabel('Number of appointment');


# ## From the chart above will find postive relationship between neighbourhood zone and the Number of Appointment 

# # * Q6: what is the effect of the SMS- received on Appointment booking??

# In[54]:


df.SMS_received.value_counts().plot(kind='line');
plt.title('SMS-Receiced Effect');
plt.xlabel('Number of Apointment');
plt.ylabel('SMS Receive');


# ## We will find an negative relationship between the SMS reciving and Nuper of appointment so this tools is not effective.

# In[39]:


df_0= df[['Gender','Age','Neighbourhood','showed']]


# In[41]:


df_0


# # * Q 6: what is effect of the Age to missed the appoiment?

# In[56]:


miss=df['showed']=='Yes'
show=df['showed']=='No'


# In[62]:


df[show].Age.hist(alpha=1, bins=20,label="showed");
df[miss].Age.hist(alpha=1, bins=20,label="missed");
plt.title('Age show correlation');
plt.legend();


# ## we can see the age is not effective in Appontment cancelation and also can see the lower cancelation comparing with booking appointment from 0-5 years and from 40-60 years 

# # Q8: what is effect of the Gender to missed the appoiment?

# In[63]:


df[show].Gender.hist(alpha=1, bins=10,label="showed");
df[miss].Gender.hist(alpha=1, bins=10,label="missed");
plt.title('Femal- male show correlation');
plt.legend();
plt.xlabel('Female -Male correlation');
plt.ylabel('Appointment Number');


# ## we can see the Generd effictive on Appointment cancelation and the male is more cancelation comparing with Number of appointoment

#                            ------------------------------------------

# # * General Data Profiling

# In[32]:


pip install pandas-profiling


# In[33]:


import pandas_profiling


# In[34]:


pandas_profiling.ProfileReport(df)


# ## Data profiling get us conclusions around the data status and confirmed for us no missing or duplicated rows and making data describting for every variable that hepling us to get overview about all vriable and how to using it

#                   ---------------------------------------------------------------------

# # * Data Cleaning Conclusions

# ##### checked all te data type and fixed to correct type helping us to using on the analysis .
# ##### checking for missing and duplicated data didn't find any of the both.
# ##### checking for outlir data and got a negative value on Age column and drop it from data set.
# ##### now the data is ready to analysis and run data set profiling .

#                           -----------------------------------------------------

# # * Data Analysis Conclusions

# ##### * the most of medical appointment booking are female.
# ##### * only 3 % of medical Appointment were cancelation.
# ##### * almost of medical appointemnt booking between 0-60 years.
# ##### * the SMS is not effective in the Appointment booking.
# ##### * the men were cancelation the appointment more than the women.
# ##### * the patient are colser from medical center were more attended the medical appointment.
# ##### * Only 19.7% Alcoholism from patient .
# ##### *Only 7% are 'Diabetes' , 3% 'Hipertension' & 2 % Handcap.

# ## *Dataset limitation

# ##### * Some Neigboorhoods don't have enough patients data.
# ##### * Appointment date doesn't have an actual time but the day only.
# ##### * Negative value in age column.

#                          -------------------------------------------
